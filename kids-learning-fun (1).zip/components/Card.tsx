
import React from 'react';
import { LearningItem } from '../types';

interface CardProps {
  item: LearningItem;
  color: string;
  onCardClick: (item: LearningItem) => void;
  isBengali: boolean;
}

const Card: React.FC<CardProps> = ({ item, color, onCardClick, isBengali }) => {
  const fontClass = isBengali ? 'font-bengali' : '';
  
  return (
    <div
      onClick={() => onCardClick(item)}
      className={`group cursor-pointer rounded-2xl shadow-lg flex flex-col items-center justify-center p-4 aspect-square transition-transform duration-300 ease-in-out hover:scale-105 hover:-rotate-3 active:scale-95 ${color}`}
    >
      {item.image && (
        <img 
          src={item.image} 
          alt={item.pronunciation}
          className="w-20 h-20 md:w-24 md:h-24 object-cover rounded-lg mb-2 shadow-md"
        />
      )}
      <span className={`text-5xl md:text-7xl font-bold text-white text-center drop-shadow-md ${fontClass}`}>
        {item.character}
      </span>
    </div>
  );
};

export default Card;
