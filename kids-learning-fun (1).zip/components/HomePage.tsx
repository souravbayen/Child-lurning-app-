
import React from 'react';
import { View } from '../types';

interface HomePageProps {
  onNavigate: (view: View) => void;
}

const HomeButton: React.FC<{ onClick: () => void; color: string; title: string; subtitle: string; isBengali?: boolean }> = ({ onClick, color, title, subtitle, isBengali = false }) => {
  const titleClass = isBengali ? 'font-bengali text-5xl' : 'text-4xl';
  const subtitleClass = isBengali ? 'font-bengali' : '';
  
  return (
    <button
      onClick={onClick}
      className={`w-full max-w-sm h-36 rounded-2xl text-white font-bold shadow-xl transform hover:scale-105 active:scale-95 transition-all duration-300 ease-in-out flex flex-col items-center justify-center ${color}`}
    >
      <span className={titleClass}>{title}</span>
      <span className={`mt-1 text-lg opacity-90 ${subtitleClass}`}>{subtitle}</span>
    </button>
  );
}

const HomePage: React.FC<HomePageProps> = ({ onNavigate }) => {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-sky-100 space-y-6">
      <div className="text-center mb-4">
        <h1 className="text-5xl md:text-6xl font-black text-gray-800 tracking-tight">Kids Learning Fun</h1>
        <p className="text-gray-600 mt-2">Let's learn and play!</p>
      </div>
      
      <HomeButton 
        onClick={() => onNavigate('BENGALI_ALPHABETS')}
        color="bg-gradient-to-br from-red-400 to-red-600"
        title="বাংলা অক্ষর"
        subtitle="Bengali Alphabets"
        isBengali
      />

      <HomeButton 
        onClick={() => onNavigate('ENGLISH_ALPHABETS')}
        color="bg-gradient-to-br from-blue-400 to-blue-600"
        title="English"
        subtitle="ABC"
      />
      
      <HomeButton 
        onClick={() => onNavigate('BENGALI_NUMBERS')}
        color="bg-gradient-to-br from-green-400 to-green-600"
        title="বাংলা সংখ্যা"
        subtitle="Bengali Numbers"
        isBengali
      />
      
      <HomeButton 
        onClick={() => onNavigate('BENGALI_RHYMES')}
        color="bg-gradient-to-br from-purple-400 to-purple-600"
        title="বাংলা ছড়া"
        subtitle="Bengali Rhymes"
        isBengali
      />

      <HomeButton 
        onClick={() => onNavigate('ENGLISH_NUMBERS')}
        color="bg-gradient-to-br from-yellow-400 to-yellow-600"
        title="English"
        subtitle="Numbers"
      />
    </div>
  );
};

export default HomePage;
