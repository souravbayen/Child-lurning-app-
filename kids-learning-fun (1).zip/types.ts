
export interface LearningItem {
  character: string;
  pronunciation: string;
  image?: string;
}

export type View = 'HOME' | 'BENGALI_ALPHABETS' | 'ENGLISH_ALPHABETS' | 'BENGALI_NUMBERS' | 'ENGLISH_NUMBERS' | 'BENGALI_RHYMES';

export type Language = 'en-US' | 'bn-BD';
