
import { Language } from '../types';

export const audioService = {
  speak: (text: string, lang: Language) => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = lang;
      utterance.rate = 0.9;
      window.speechSynthesis.cancel(); // Cancel any previous speech
      window.speechSynthesis.speak(utterance);
    } else {
      console.error('Speech Synthesis not supported in this browser.');
      alert('Sorry, your browser does not support audio playback for this app.');
    }
  },
};
