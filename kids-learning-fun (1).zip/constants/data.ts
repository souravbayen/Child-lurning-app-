
import { LearningItem } from '../types';

export const BENGALI_ALPHABETS: LearningItem[] = [
  { character: 'অ', pronunciation: 'অ' }, { character: 'আ', pronunciation: 'আ' },
  { character: 'ই', pronunciation: 'ই' }, { character: 'ঈ', pronunciation: 'ঈ' },
  { character: 'উ', pronunciation: 'উ' }, { character: 'ঊ', pronunciation: 'ঊ' },
  { character: 'ঋ', pronunciation: 'ঋ' }, { character: 'এ', pronunciation: 'এ' },
  { character: 'ঐ', pronunciation: 'ঐ' }, { character: 'ও', pronunciation: 'ও' },
  { character: 'ঔ', pronunciation: 'ঔ' }, { character: 'ক', pronunciation: 'ক' },
  { character: 'খ', pronunciation: 'খ' }, { character: 'গ', pronunciation: 'গ' },
  { character: 'ঘ', pronunciation: 'ঘ' }, { character: 'ঙ', pronunciation: 'ঙ' },
  { character: 'চ', pronunciation: 'চ' }, { character: 'ছ', pronunciation: 'ছ' },
  { character: 'জ', pronunciation: 'জ' }, { character: 'ঝ', pronunciation: 'ঝ' },
  { character: 'ঞ', pronunciation: 'ঞ' }, { character: 'ট', pronunciation: 'ট' },
  { character: 'ঠ', pronunciation: 'ঠ' }, { character: 'ড', pronunciation: 'ড' },
  { character: 'ঢ', pronunciation: 'ঢ' }, { character: 'ণ', pronunciation: 'ণ' },
  { character: 'ত', pronunciation: 'ত' }, { character: 'থ', pronunciation: 'থ' },
  { character: 'দ', pronunciation: 'দ' }, { character: 'ধ', pronunciation: 'ধ' },
  { character: 'ন', pronunciation: 'ন' }, { character: 'প', pronunciation: 'প' },
  { character: 'ফ', pronunciation: 'ফ' }, { character: 'ব', pronunciation: 'ব' },
  { character: 'ভ', pronunciation: 'ভ' }, { character: 'ম', pronunciation: 'ম' },
  { character: 'য', pronunciation: 'য' }, { character: 'র', pronunciation: 'র' },
  { character: 'ল', pronunciation: 'ল' }, { character: 'শ', pronunciation: 'শ' },
  { character: 'ষ', pronunciation: 'ষ' }, { character: 'স', pronunciation: 'স' },
  { character: 'হ', pronunciation: 'হ' },
];

export const ENGLISH_ALPHABETS: LearningItem[] = [
  { character: 'A', pronunciation: 'A for Apple', image: 'https://picsum.photos/seed/apple/200' },
  { character: 'B', pronunciation: 'B for Ball', image: 'https://picsum.photos/seed/ball/200' },
  { character: 'C', pronunciation: 'C for Cat', image: 'https://picsum.photos/seed/cat/200' },
  { character: 'D', pronunciation: 'D for Dog', image: 'https://picsum.photos/seed/dog/200' },
  { character: 'E', pronunciation: 'E for Elephant', image: 'https://picsum.photos/seed/elephant/200' },
  { character: 'F', pronunciation: 'F for Fish', image: 'https://picsum.photos/seed/fish/200' },
  { character: 'G', pronunciation: 'G for Goat', image: 'https://picsum.photos/seed/goat/200' },
  { character: 'H', pronunciation: 'H for Hat', image: 'https://picsum.photos/seed/hat/200' },
  { character: 'I', pronunciation: 'I for Igloo', image: 'https://picsum.photos/seed/igloo/200' },
  { character: 'J', pronunciation: 'J for Jar', image: 'https://picsum.photos/seed/jar/200' },
  { character: 'K', pronunciation: 'K for Kite', image: 'https://picsum.photos/seed/kite/200' },
  { character: 'L', pronunciation: 'L for Lion', image: 'https://picsum.photos/seed/lion/200' },
  { character: 'M', pronunciation: 'M for Mango', image: 'https://picsum.photos/seed/mango/200' },
  { character: 'N', pronunciation: 'N for Nest', image: 'https://picsum.photos/seed/nest/200' },
  { character: 'O', pronunciation: 'O for Orange', image: 'https://picsum.photos/seed/orange/200' },
  { character: 'P', pronunciation: 'P for Panda', image: 'https://picsum.photos/seed/panda/200' },
  { character: 'Q', pronunciation: 'Q for Queen', image: 'https://picsum.photos/seed/queen/200' },
  { character: 'R', pronunciation: 'R for Rabbit', image: 'https://picsum.photos/seed/rabbit/200' },
  { character: 'S', pronunciation: 'S for Sun', image: 'https://picsum.photos/seed/sun/200' },
  { character: 'T', pronunciation: 'T for Tiger', image: 'https://picsum.photos/seed/tiger/200' },
  { character: 'U', pronunciation: 'U for Umbrella', image: 'https://picsum.photos/seed/umbrella/200' },
  { character: 'V', pronunciation: 'V for Violin', image: 'https://picsum.photos/seed/violin/200' },
  { character: 'W', pronunciation: 'W for Watch', image: 'https://picsum.photos/seed/watch/200' },
  { character: 'X', pronunciation: 'X for Xylophone', image: 'https://picsum.photos/seed/xylophone/200' },
  { character: 'Y', pronunciation: 'Y for Yo-yo', image: 'https://picsum.photos/seed/yoyo/200' },
  { character: 'Z', pronunciation: 'Z for Zebra', image: 'https://picsum.photos/seed/zebra/200' },
];

export const BENGALI_NUMBERS: LearningItem[] = [
  { character: '১', pronunciation: 'এক' }, { character: '২', pronunciation: 'দুই' },
  { character: '৩', pronunciation: 'তিন' }, { character: '৪', pronunciation: 'চার' },
  { character: '৫', pronunciation: 'পাঁচ' }, { character: '৬', pronunciation: 'ছয়' },
  { character: '৭', pronunciation: 'সাত' }, { character: '৮', pronunciation: 'আট' },
  { character: '৯', pronunciation: 'নয়' }, { character: '১০', pronunciation: 'দশ' },
];

export const ENGLISH_NUMBERS: LearningItem[] = [
  { character: '1', pronunciation: 'One' }, { character: '2', pronunciation: 'Two' },
  { character: '3', pronunciation: 'Three' }, { character: '4', pronunciation: 'Four' },
  { character: '5', pronunciation: 'Five' }, { character: '6', pronunciation: 'Six' },
  { character: '7', pronunciation: 'Seven' }, { character: '8', pronunciation: 'Eight' },
  { character: '9', pronunciation: 'Nine' }, { character: '10', pronunciation: 'Ten' },
];

export const BENGALI_RHYMES: LearningItem[] = [
    { character: '১', pronunciation: 'একে চন্দ্র', image: 'https://picsum.photos/seed/moon/200' },
    { character: '২', pronunciation: 'দুয়ে পক্ষ', image: 'https://picsum.photos/seed/sides/200' },
    { character: '৩', pronunciation: 'তিনে নেত্র', image: 'https://picsum.photos/seed/eyes/200' },
    { character: '৪', pronunciation: 'চারে বেদ', image: 'https://picsum.photos/seed/vedas/200' },
    { character: '৫', pronunciation: 'পাঁচে পঞ্চবাণ', image: 'https://picsum.photos/seed/arrows/200' },
    { character: '৬', pronunciation: 'ছয়ে ঋতু', image: 'https://picsum.photos/seed/seasons/200' },
    { character: '৭', pronunciation: 'সাতে সমুদ্র', image: 'https://picsum.photos/seed/seas/200' },
    { character: '৮', pronunciation: 'আটে অষ্টবসু', image: 'https://picsum.photos/seed/vasus/200' },
    { character: '৯', pronunciation: 'নয়ে নবগ্রহ', image: 'https://picsum.photos/seed/planets/200' },
    { character: '১০', pronunciation: 'দশে দিক', image: 'https://picsum.photos/seed/directions/200' },
];
