
import React, { useState } from 'react';
import { LearningItem, Language } from '../types';
import { audioService } from '../services/audioService';
import { aiService } from '../services/aiService';
import Card from './Card';

interface LearningGridProps {
  title: string;
  items: LearningItem[];
  lang: Language;
  onBack: () => void;
  showPronunciation?: boolean;
}

const COLORS = [
  'bg-pink-400', 'bg-blue-400', 'bg-green-400',
  'bg-yellow-400', 'bg-purple-400', 'bg-orange-400',
];

const LearningGrid: React.FC<LearningGridProps> = ({ title, items, lang, onBack, showPronunciation = false }) => {
  const [loadingItem, setLoadingItem] = useState<string | null>(null);
  
  const handleCardClick = async (item: LearningItem) => {
    // Prevent clicking another card while one is active.
    if (loadingItem) return;

    setLoadingItem(item.character);
    try {
      // 1. Play the item's sound (file or TTS) and wait for it to finish.
      await audioService.playItemSound(item, lang);
      
      // 2. Fetch fun fact from Gemini. Use specific topic if available.
      const topic = item.topic || item.pronunciation;
      const fact = await aiService.getFunFact(topic, lang);

      // 3. Speak the fun fact and wait for it to finish.
      if (fact) {
        await audioService.speakText(fact, lang);
      }
    } catch (error) {
      console.error("Failed during learning interaction:", error);
      // Optional: show a user-friendly error message.
    } finally {
      // Ensure loading state is always cleared.
      setLoadingItem(null);
    }
  };

  const isBengali = lang === 'bn-BD';
  const titleFont = isBengali ? 'font-bengali' : 'font-extrabold';

  return (
    <div className="p-4 md:p-8 max-w-5xl mx-auto w-full min-h-screen">
      <header className="flex items-center justify-between mb-6">
        <button
          onClick={onBack}
          className="bg-white text-gray-700 font-bold p-3 rounded-full shadow-md hover:bg-gray-100 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-sky-500"
          aria-label="Go back to home page"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
        </button>
        <h1 className={`flex-1 text-center text-3xl md:text-5xl text-gray-700 mx-4 ${titleFont}`}>
          {title}
        </h1>
        <div className="w-12 h-12"></div> {/* Spacer to balance the back button */}
      </header>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 md:gap-6">
        {items.map((item, index) => (
          <Card
            key={item.character}
            item={item}
            color={COLORS[index % COLORS.length]}
            onCardClick={handleCardClick}
            isBengali={isBengali}
            showPronunciation={showPronunciation}
            isLoading={loadingItem === item.character}
          />
        ))}
      </div>
    </div>
  );
};

export default LearningGrid;