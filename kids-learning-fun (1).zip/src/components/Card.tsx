
import React from 'react';
import { LearningItem } from '../types';

interface CardProps {
  item: LearningItem;
  color: string;
  onCardClick: (item: LearningItem) => void;
  isBengali: boolean;
  showPronunciation?: boolean;
  isLoading?: boolean;
}

const Card: React.FC<CardProps> = ({ item, color, onCardClick, isBengali, showPronunciation = false, isLoading = false }) => {
  const fontClass = isBengali ? 'font-bengali' : '';
  
  const handleKeyPress = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if ((e.key === 'Enter' || e.key === ' ') && !isLoading) {
      e.preventDefault();
      onCardClick(item);
    }
  };

  const bgColor = item.colorCode || color;
  const textColor = item.textColor || 'text-white';
  const characterFontSize = item.colorCode ? 'text-4xl md:text-5xl' : 'text-5xl sm:text-6xl';

  return (
    <div
      onClick={() => !isLoading && onCardClick(item)}
      onKeyDown={handleKeyPress}
      tabIndex={0}
      role="button"
      aria-label={`Learn about ${item.pronunciation}`}
      className={`group relative cursor-pointer rounded-2xl shadow-lg flex flex-col items-center justify-center p-2 sm:p-4 aspect-square transition-all duration-300 ease-in-out hover:scale-105 hover:-rotate-3 active:scale-95 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-sky-50 focus:ring-white ${bgColor} ${isLoading ? 'cursor-wait' : ''}`}
    >
      {isLoading && (
        <div className="absolute inset-0 bg-black/50 rounded-2xl flex items-center justify-center">
          <svg className="animate-spin h-10 w-10 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
        </div>
      )}
      {item.image && (
        <img 
          src={item.image} 
          alt=""
          aria-hidden="true"
          className="w-16 h-16 sm:w-20 sm:h-20 object-cover rounded-lg mb-2 shadow-md"
        />
      )}
      <div className="text-center">
        <span className={`${characterFontSize} font-bold drop-shadow-md ${fontClass} ${textColor}`}>
          {item.character}
        </span>
        {showPronunciation && (
          <p className={`mt-1 text-base sm:text-lg font-semibold drop-shadow-sm ${fontClass} ${textColor}`}>
            {item.pronunciation}
          </p>
        )}
      </div>
    </div>
  );
};

export default Card;