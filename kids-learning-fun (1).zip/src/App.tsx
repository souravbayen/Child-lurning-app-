
import React, { useState } from 'react';
import HomePage from './components/HomePage';
import LearningGrid from './components/LearningGrid';
import { View } from './types';
import { 
  BENGALI_ALPHABETS, 
  ENGLISH_ALPHABETS, 
  ENGLISH_NUMBERS,
  BENGALI_RHYMES,
  BENGALI_COLORS,
  ENGLISH_COLORS
} from './constants/data';

function App() {
  const [currentView, setCurrentView] = useState<View>('HOME');

  const handleNavigate = (view: View) => {
    setCurrentView(view);
  };

  const handleBack = () => {
    setCurrentView('HOME');
  };

  const renderView = () => {
    switch (currentView) {
      case 'BENGALI_ALPHABETS':
        return <LearningGrid title="বাংলা অক্ষর" items={BENGALI_ALPHABETS} lang="bn-BD" onBack={handleBack} />;
      case 'ENGLISH_ALPHABETS':
        return <LearningGrid title="English ABC" items={ENGLISH_ALPHABETS} lang="en-US" onBack={handleBack} />;
      case 'BENGALI_RHYMES':
        return <LearningGrid title="বাংলা সংখ্যা" items={BENGALI_RHYMES} lang="bn-BD" onBack={handleBack} showPronunciation />;
      case 'ENGLISH_NUMBERS':
        return <LearningGrid title="English Numbers" items={ENGLISH_NUMBERS} lang="en-US" onBack={handleBack} />;
      case 'BENGALI_COLORS':
        return <LearningGrid title="বাংলা রং" items={BENGALI_COLORS} lang="bn-BD" onBack={handleBack} />;
      case 'ENGLISH_COLORS':
        return <LearningGrid title="English Colors" items={ENGLISH_COLORS} lang="en-US" onBack={handleBack} />;
      case 'HOME':
      default:
        return <HomePage onNavigate={handleNavigate} />;
    }
  };

  return (
    <main className="w-full">
      {renderView()}
    </main>
  );
}

export default App;