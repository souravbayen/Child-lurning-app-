
export interface LearningItem {
  character: string;
  pronunciation: string;
  image?: string;
  colorCode?: string;
  textColor?: string;
  audioSrc?: string;
  topic?: string;
}

export type View = 'HOME' | 'BENGALI_ALPHABETS' | 'ENGLISH_ALPHABETS' | 'ENGLISH_NUMBERS' | 'BENGALI_RHYMES' | 'BENGALI_COLORS' | 'ENGLISH_COLORS';

export type Language = 'en-US' | 'bn-BD';