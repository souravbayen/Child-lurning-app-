
import { LearningItem, Language } from '../types';

const audioPlayer = new Audio();

/**
 * Wraps audio file playback in a Promise.
 * Resolves when playback finishes, rejects on error (e.g., file not found).
 */
const playAudioFile = (src: string): Promise<void> => {
  return new Promise((resolve, reject) => {
    // Make sure any browser speech is stopped.
    window.speechSynthesis.cancel();
    
    audioPlayer.src = src;

    const onEnded = () => {
      cleanup();
      resolve();
    };

    const onError = () => {
      cleanup();
      const error = audioPlayer.error || new Error('Audio playback failed');
      console.error(`Error playing audio file: ${src}`, error);
      reject(error);
    };

    const cleanup = () => {
      audioPlayer.removeEventListener('ended', onEnded);
      audioPlayer.removeEventListener('error', onError);
    };
    
    audioPlayer.addEventListener('ended', onEnded);
    audioPlayer.addEventListener('error', onError);

    // play() returns a promise which can reject if playback is interrupted
    // or not allowed by the browser.
    audioPlayer.play().catch(onError);
  });
};

/**
 * Wraps SpeechSynthesis in a Promise.
 * Resolves when speech finishes, rejects on error.
 */
const speakText = (text: string, lang: Language): Promise<void> => {
  return new Promise((resolve, reject) => {
    if (!('speechSynthesis' in window)) {
      return reject(new Error('Speech Synthesis not supported.'));
    }
    
    // Stop any file playback and other speech.
    if (!audioPlayer.paused) audioPlayer.pause();
    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = lang;
    utterance.rate = 0.9;
    utterance.pitch = lang === 'bn-BD' ? 1.2 : 1.0;

    utterance.onend = () => resolve();
    utterance.onerror = (event) => {
        console.error('SpeechSynthesis Error:', event.error);
        reject(event.error);
    };

    window.speechSynthesis.speak(utterance);
  });
};

/**
 * Plays the sound for a learning item. Tries to play a high-quality audio
 * file first, but falls back to synthesized speech if the file is missing or fails to load.
 */
const playItemSound = async (item: LearningItem, lang: Language): Promise<void> => {
  if (item.audioSrc) {
    try {
      await playAudioFile(item.audioSrc);
    } catch (error) {
      console.warn(`Could not play audio file for "${item.pronunciation}". Falling back to TTS.`);
      // If the file fails, speak the pronunciation instead.
      await speakText(item.pronunciation, lang);
    }
  } else {
    // If no audio file is specified, just use TTS.
    await speakText(item.pronunciation, lang);
  }
};

export const audioService = {
  playItemSound,
  speakText,
};