
import { GoogleGenAI } from "@google/genai";
import { Language } from "../types";

// IMPORTANT: This assumes the API_KEY is set in the execution environment.
// Do not handle the key in the UI.
const apiKey = process.env.API_KEY;
if (!apiKey) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey });

const getSystemInstruction = (lang: Language) => {
    if (lang === 'bn-BD') {
        return "তুমি ৫ বছর বয়সী শিশুদের জন্য একজন বন্ধুত্বপূর্ণ শিক্ষক। তোমার উত্তরগুলো হবে খুবই সহজ বাংলা ভাষায় এবং একটি মাত্র ছোট বাক্যের মধ্যে সীমাবদ্ধ থাকবে।";
    }
    return "You are a friendly teacher for 5-year-old children. Your answers will be in very simple English and limited to a single, short sentence.";
}

const getFunFact = async (topic: string, lang: Language): Promise<string | null> => {
  try {
    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: `Tell me a fun fact about: ${topic}`,
        config: {
            systemInstruction: getSystemInstruction(lang),
            temperature: 0.8,
            topK: 10,
        }
    });
    return response.text;
  } catch (error) {
    console.error("Gemini API call failed:", error);
    // Return null or a fallback message on error.
    return lang === 'bn-BD' ? "কিছু একটা সমস্যা হয়েছে।" : "Oops, something went wrong.";
  }
};

export const aiService = {
  getFunFact,
};
