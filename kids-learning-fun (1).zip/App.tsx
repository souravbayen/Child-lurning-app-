
import React, { useState } from 'react';
import HomePage from './components/HomePage';
import LearningGrid from './components/LearningGrid';
import { View } from './types';
import { 
  BENGALI_ALPHABETS, 
  ENGLISH_ALPHABETS, 
  BENGALI_NUMBERS, 
  ENGLISH_NUMBERS,
  BENGALI_RHYMES
} from './constants/data';

function App() {
  const [currentView, setCurrentView] = useState<View>('HOME');

  const handleNavigate = (view: View) => {
    setCurrentView(view);
  };

  const handleBack = () => {
    setCurrentView('HOME');
  };

  const renderView = () => {
    switch (currentView) {
      case 'BENGALI_ALPHABETS':
        return <LearningGrid title="বাংলা অক্ষর" items={BENGALI_ALPHABETS} lang="bn-BD" onBack={handleBack} />;
      case 'ENGLISH_ALPHABETS':
        return <LearningGrid title="English ABC" items={ENGLISH_ALPHABETS} lang="en-US" onBack={handleBack} />;
      case 'BENGALI_NUMBERS':
        return <LearningGrid title="বাংলা সংখ্যা" items={BENGALI_NUMBERS} lang="bn-BD" onBack={handleBack} />;
      case 'BENGALI_RHYMES':
        return <LearningGrid title="বাংলা সংখ্যা" items={BENGALI_RHYMES} lang="bn-BD" onBack={handleBack} />;
      case 'ENGLISH_NUMBERS':
        return <LearningGrid title="English Numbers" items={ENGLISH_NUMBERS} lang="en-US" onBack={handleBack} />;
      case 'HOME':
      default:
        return <HomePage onNavigate={handleNavigate} />;
    }
  };

  return (
    <main className="w-full">
      {renderView()}
    </main>
  );
}

export default App;
